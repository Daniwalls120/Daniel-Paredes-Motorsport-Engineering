# Daniel Paredes — Motorsport Engineering portfolio

## Primera versión · Home

Web estática responsive en **HTML + CSS + JavaScript nativo**, sin instalaciones, librerías de animación ni suscripciones.

### Cómo abrirla en tu ordenador

1. Descomprime el ZIP.
2. Abre **`index.html`** con Chrome, Edge o Firefox.
3. Baja por la página: Home > About Me > Engineering Projects > On-Track Experience > Footer.
4. La cabecera con cinco pestañas se mantiene en todas las páginas.

Si quieres probarla con un servidor local: en la carpeta de la web, ejecuta `python -m http.server 8000` y abre `http://localhost:8000`.

### Cómo modificar textos

- **`index.html`**: todos los textos, enlaces y estructura de Home.
- **`about.html`**: la siguiente página, ahora como versión introductoria. Puedes ampliar con la historia completa.
- **`engineering-projects.html`**: la página de proyectos con Formula Student y personales. Es un esqueleto a completar.
- **`on-track.html`**: galería de circuito, provisional hasta añadir tus fotos.
- **`styles.css`**: diseño, colores, tipografías, adaptación móvil y animaciones.
- **`script.js`**: scroll progresivo, menú móvil, transiciones, gráfica dinámica.
- **`images.js`**: **todas las imágenes en un solo sitio** (recomendado para cambios rápidos).

### Cómo poner tus propias fotos

1. Copia tus imágenes dentro de `assets/`, por ejemplo `assets/upm-racing.jpg`.
2. Abre `images.js` y sustituye la URL correspondiente por `assets/upm-racing.jpg`.
3. Guarda el archivo y actualiza la web.

Campos disponibles: `hero`, `about`, `formulaStudent`, `personal`, `track1`, `track2`, `track3`, `track4`.

**Importante:** Las fotografías enlazadas inicialmente son ilustrativas, no se presentan como imágenes de tus experiencias reales. El gráfico de suspensión y la gráfica animada son elementos del diseño; no representan validación de un proyecto real. El gráfico de suspensión se muestra por defecto hasta que subas tu propia foto.

### Cómo publicar gratis con Vercel

1. Sube esta carpeta a un repositorio GitHub (sin colocar datos privados en él).
2. Conecta el repositorio en [vercel.com](https://vercel.com) → `Add New` → `Project`.
3. Framework Preset: `Other`; **sin comando de build**; directorio raíz del repositorio.
4. Publica: tendrás una URL gratuita `*.vercel.app`.
5. Al actualizar el repositorio, se publica automáticamente la nueva versión.

Para este sitio personal estático, también puedes usar GitHub Pages de forma gratuita. No necesitas pagar un dominio ni usar React o Node.

### Compatibilidad y accesibilidad

- Diseño adaptable a móvil y escritorio.
- Animaciones al hacer scroll con `IntersectionObserver`, progreso de lectura y parallax moderado.
- Gráfico analítico animado de un oscilador amortiguado de un grado de libertad, dibujado con Canvas 2D.
- Menú móvil accesible mediante teclado y atributos ARIA.
- Respeto por la preferencia del sistema `prefers-reduced-motion`.
- Enlaces directos `mailto:` y `tel:` en el pie.

Licencias y enlaces de las imágenes provisionales: `PHOTO_CREDITS.md`.
