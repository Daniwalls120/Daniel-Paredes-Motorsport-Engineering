/*
 * IMAGE CONFIGURATION
 * Replace any URL with your own photo, e.g. 'assets/my-upm-racing-photo.jpg'.
 * These initial images are illustrative Unsplash placeholders, NOT photographs of Daniel.
 * Source and credits are in PHOTO_CREDITS.md.
 */
window.PORTFOLIO_IMAGES = {
  hero: 'https://images.unsplash.com/photo-1642795633020-d6d30ebde918?auto=format&fit=crop&w=2100&q=85',
  about: 'https://images.unsplash.com/photo-1749269644713-7177d3136a5d?auto=format&fit=crop&w=1000&q=82',
  formulaStudent: '', // Add your real Formula Student photo later
  personal: 'https://images.unsplash.com/photo-1723820751318-ac07be00cccd?auto=format&fit=crop&w=1150&q=82',
  track1: 'https://images.unsplash.com/photo-1723820751318-ac07be00cccd?auto=format&fit=crop&w=900&q=78',
  track2: 'https://images.unsplash.com/photo-1749269644713-7177d3136a5d?auto=format&fit=crop&w=900&q=78',
  track3: 'https://images.unsplash.com/photo-1624457486734-283c9b79eb0b?auto=format&fit=crop&w=900&q=78',
  track4: 'https://images.unsplash.com/photo-1660765401277-cb90d1b746b4?auto=format&fit=crop&w=900&q=78'
};
