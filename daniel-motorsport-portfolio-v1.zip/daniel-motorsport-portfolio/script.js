(() => {
  'use strict';
  document.documentElement.classList.add('js');

  // Load images from images.js, keeping a readable, local visual fallback.
  document.querySelectorAll('[data-photo]').forEach(img => {
    const url = window.PORTFOLIO_IMAGES?.[img.dataset.photo];
    if (!url) {
      img.remove();
      return;
    }
    img.addEventListener('error', () => img.remove(), { once: true });
    img.src = url;
  });

  document.querySelectorAll('.current-year').forEach(el => el.textContent = String(new Date().getFullYear()));
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (toggle && nav) {
    function closeMenu() {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Open menu');
      nav.classList.remove('open');
    }
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
      nav.classList.toggle('open', open);
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
    document.addEventListener('click', e => { if (!nav.contains(e.target) && !toggle.contains(e.target)) closeMenu(); });
  }

  // Progressive-enhancement scroll reveals, respecting reduced-motion settings.
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reveals = document.querySelectorAll('.reveal');
  if (!reduceMotion && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.11, rootMargin: '0px 0px -36px 0px' });
    reveals.forEach(el => obs.observe(el));
  } else { reveals.forEach(el => el.classList.add('visible')); }

  const header = document.querySelector('.site-header');
  const progress = document.querySelector('#page-progress-bar');
  const heroImg = document.querySelector('.hero-photo img');
  let scrollRaf = 0;
  function updateScroll() {
    const y = Math.max(0, window.scrollY);
    header?.classList.toggle('is-scrolled', y > 18);
    const max = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    if (progress) progress.style.width = `${(y / max) * 100}%`;
    // Very subtle parallax; clamped to hero and turned off for reduced-motion.
    if (heroImg && !reduceMotion) heroImg.style.transform = `scale(1.09) translate3d(0,${Math.min(y,700)*.085}px,0)`;
    scrollRaf = 0;
  }
  window.addEventListener('scroll', () => {
    if (!scrollRaf) scrollRaf = requestAnimationFrame(updateScroll);
  }, { passive: true });
  updateScroll();

  // Animated model trace: a damped 1-DOF response. Canvas is deliberately
  // self-contained (no external JavaScript libraries or frameworks).
  const canvas = document.getElementById('telemetry');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    const host = canvas.closest('.project-card');
    const state = { visible: true, frame: 0, last: 0 };
    const observer = new IntersectionObserver(e => state.visible = e[0].isIntersecting, { threshold: 0.01 });
    observer.observe(host);

    function render(timestamp) {
      requestAnimationFrame(render);
      if (!state.visible || !ctx || document.hidden) return;
      if (timestamp - state.last < 33) return; // ~30 FPS max
      state.last = timestamp;
      const rect = canvas.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = rect.width, h = rect.height;
      if (canvas.width !== Math.round(w*dpr) || canvas.height !== Math.round(h*dpr)) {
        canvas.width = Math.round(w*dpr);
        canvas.height = Math.round(h*dpr);
      }
      ctx.setTransform(dpr,0,0,dpr,0,0);
      ctx.clearRect(0,0,w,h);
      ctx.lineWidth = .6;
      ctx.strokeStyle = 'rgba(162,193,199,.17)';
      for (let i=0; i<=7; i++) { const x=i*w/7;ctx.beginPath();ctx.moveTo(x,4);ctx.lineTo(x,h-5);ctx.stroke(); }
      for (let i=0; i<=4; i++) { const y=i*(h-9)/4+4;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke(); }
      const phase = reduceMotion ? 0 : timestamp*.001;
      const base = h*.53;
      const amplitude = h*.29;
      const yAt = t => base - Math.exp(-t*.24)*Math.cos(t*3.3)*amplitude;
      // Analytical response line (exp. decay); traces update at 30fps.
      ctx.beginPath();
      for (let i=0;i<=w;i+=2) {
        const t=i/w*11.7;
        const y=yAt(t);
        if(i===0)ctx.moveTo(i,y); else ctx.lineTo(i,y);
      }
      ctx.strokeStyle='rgba(231,163,132,.97)';ctx.lineWidth=2.3;ctx.shadowColor='rgba(237,158,120,.4)';ctx.shadowBlur=9;ctx.stroke();ctx.shadowBlur=0;
      const cursor = ((phase*47) % w);
      const cy = yAt(cursor/w*11.7);
      ctx.strokeStyle='rgba(222,237,234,.6)';ctx.lineWidth=.65;ctx.setLineDash([3,5]);ctx.beginPath();ctx.moveTo(cursor,2);ctx.lineTo(cursor,h);ctx.stroke();ctx.setLineDash([]);
      ctx.fillStyle='#f5ccad';ctx.beginPath();ctx.arc(cursor,cy,3.2,0,Math.PI*2);ctx.fill();
    }
    requestAnimationFrame(render);
  }
})();
