# Provisional images — credits and licensing

The following external photos are examples included in this initial mock-up. They are **not** Daniel's Formula Student or on-track photographs. All are sourced from [Unsplash](https://unsplash.com/license) with free usage permitted under the Unsplash License, subject to its terms.

- **Hero / racing circuit** — Michal Wojcik, [Spa Francorchamps view](https://unsplash.com/photos/a-view-of-a-race-track-from-a-distance-h2UjzXMyAD4).
- **About / karting** — Sulthan Apyandra, [go-karts on track](https://unsplash.com/photos/go-karts-race-around-a-track-at-high-speed-Ultrn2hrYSs).
- **Personal projects / race car**, **Track 1** — Boris Debusscher, [race car at Spa](https://unsplash.com/photos/a-race-car-driving-down-a-race-track-ZmCHTylNVro).
- **Track 2** — Sulthan Apyandra, [karting](https://unsplash.com/photos/go-karts-race-around-a-track-at-high-speed-Ultrn2hrYSs).
- **Track 3** — Louis Verplancken, [2018 Spa 24h](https://unsplash.com/photos/black-car-on-road-during-daytime-gT-WsJLBJvQ).
- **Track 4** — Cédric Streit, [race car](https://unsplash.com/photos/a-race-car-on-a-track-7qqjZ5sI56w).

The header's local SVG fallback is an original graphic. The suspension schematic is an original decorative SVG sketch, not a validated engineering drawing.

**Once Daniel provides original images**, replace all sample photos to ensure the portfolio is clearly based on his own experiences and work.
